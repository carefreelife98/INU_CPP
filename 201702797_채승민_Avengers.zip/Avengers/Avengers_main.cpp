#include <cstdlib>
#include "MyAvengers.h"

using namespace MyAvengers;

int main(){
    CarefreeHeroPick pick;
    pick.setHero(pick.selectHero());
    return 0;
}
