// #include <cstdlib>
// #include "../MyAvengers.h"
// #include <string>

// using namespace MyAvengers;

// std::string CarefreeHero::genHero(int hero_num){
//     return CarefreeHero::heroName[hero_num - 1];
// }